var arr = [];

function swapArray(left,right){
    var s_left = arr[left];
    var s_min = arr[right];
    arr[left] = s_min;
    arr[right] = s_left;
  }

function sendNumber(){
    const textbox = document.getElementById("number").value;
    console.log(textbox);
    arr = textbox.split(',').map(Number);
    console.log(arr);
    sort()
}

function sort(){

    for(var s = arr.length; s > 0;s--){    
        for(var i = 0; i <s;i++){
            
            if(arr[i]>arr[i+1]){
                swapArray(i,i+1);        
            }

        console.log(arr);
        }
    }    
    const output = "sorted number is " + arr + ".";
    document.getElementById("sorted-number").innerHTML = output;

}


